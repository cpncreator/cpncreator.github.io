import base64
import json
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
import os
import sys

def resource_path(relative_path):
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

def load_public_key():
    with open(resource_path("public_key.pem"), "rb") as f:
        return serialization.load_pem_public_key(f.read())

def verify_license(license_key, system_id):
    try:
        decoded = base64.b64decode(license_key.encode()).decode()
        payload, signature = decoded.split("||")

        data = json.loads(payload)
        if data.get("system_id") != system_id:
            return False, "🔒 This license key doesn't match this system."

        pubkey = load_public_key()
        pubkey.verify(
            base64.b64decode(signature.encode()),
            payload.encode(),
            padding.PKCS1v15(),
            hashes.SHA256()
        )

        return True, "✅ License is valid."
    except Exception as e:
        return False, f"❌ Invalid license: {str(e)}"
