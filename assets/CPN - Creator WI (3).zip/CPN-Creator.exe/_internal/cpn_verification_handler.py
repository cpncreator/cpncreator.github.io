import tkinter as tk
import random
import json
import os
from scan_utils import CPNVerifier


def reset_ui_focus(app):
    try:
        app.root.focus_set()
        app.root.update_idletasks()
    except:
        pass


def verify_cpn_process_label(app, ssn, label_widget, callback=None):
    if app.scanning:
        return  # Prevent multiple simultaneous scans

    label_widget.unbind("<Button-1>")
    label_widget.config(text="Verifying...", fg="white", bg="#222")
    app.clear_scanning_ui()

    # Stage container
    app.scanning_stage_log = tk.Frame(app.inner_grid_frame, bg="#1e1e1e")
    app.scanning_stage_log.grid(row=3, column=0, columnspan=5, pady=10)
    app.scanning_stage_log.grid_columnconfigure(0, weight=1)

    # Message above progress bar
    verifying_label = tk.Label(
        app.inner_grid_frame,
        text="Checking To See If This Number Is Already A CPN",
        fg="white",
        bg="#1e1e1e",
        font=("Arial", 14, "italic")
    )
    verifying_label.grid(row=2, column=0, columnspan=5, pady=(10, 5))

    app.scanning = True
    app.verifier = CPNVerifier(app.root)

    def on_finish(result):
        app.clear_scanning_ui()
        app.scanning = False

        if result == "good":
            label_widget.config(text=f"{ssn} (Good)", bg="green", fg="white")
            show_success_popup(app, ssn, label_widget)
            if callback:
                callback("good")
        else:
            label_widget.config(bg="red", fg="white")
            label_widget.after(4000, label_widget.destroy)
            if callback:
                callback("bad")

        log_history(ssn, result)
        reset_ui_focus(app)

    app.verifier.start_cpn_verification(
        label_widget=label_widget,
        ssn=ssn,
        container_frame=app.scanning_stage_log,
        verifying_label=verifying_label,
        on_finish_callback=on_finish,
        duration_per_stage=36000
    )


def show_success_popup(app, ssn, label):
    popup = tk.Toplevel(app.root)
    popup.configure(bg="#228822")
    popup.overrideredirect(True)
    popup.attributes('-topmost', True)

    # Center screen position, slightly lower
    x = app.root.winfo_rootx() + app.root.winfo_width() // 2 - 170
    y = app.root.winfo_rooty() + app.root.winfo_height() // 2 - 60
    popup.geometry(f"340x100+{x}+{y}")

    def on_copy(event=None):
        app.root.clipboard_clear()
        app.root.clipboard_append(ssn)
        app.root.update()
        popup.destroy()
        app.scanning = False
        app.clear_scanning_ui()

    label_big = tk.Label(popup, text=f"✅ {ssn}", font=("Courier", 18, "bold"),
                         fg="white", bg="#228822", cursor="hand2")
    label_big.pack(pady=(10, 2))
    label_big.bind("<Button-1>", on_copy)

    label_small = tk.Label(popup, text="Click here to copy", font=("Arial", 10),
                           fg="red", bg="#228822", cursor="hand2")
    label_small.pack()
    label_small.bind("<Button-1>", on_copy)

    def on_timeout_destroy():
        if popup.winfo_exists():
            popup.destroy()
            app.scanning = False
            app.clear_scanning_ui()

    popup.after(8000, on_timeout_destroy)


def log_history(ssn, result):
    history_file = "cpn_verification_history.json"
    if os.path.exists(history_file):
        try:
            with open(history_file, "r") as f:
                history = json.load(f)
        except json.JSONDecodeError:
            history = []
    else:
        history = []

    history.append({
        "ssn": ssn,
        "result": result,
        "timestamp": __import__('datetime').datetime.now().isoformat()
    })

    with open(history_file, "w") as f:
        json.dump(history, f, indent=2)
