# apps/demo_app.py
from apps.app_base import AppBase

class DemoApp(AppBase):
    def __init__(self, root):
        super().__init__(root, mode="demo")
