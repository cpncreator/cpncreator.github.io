# apps/app_base.py
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import re
import json
from datetime import datetime
from tkinter import ttk, messagebox, simpledialog, filedialog
import tkinter as tk
from docx import Document
from PIL import Image
import pytesseract

from scroll_wrapper import UniversalScrollableFrame
from return_handler import bind_return_key
from auto_scan_chain import AutoScanChain
from cpn_verification_handler import verify_cpn_process_label, CPNVerifier

from home_ui import show_home_content
from contact_ui import show_contact_ui
from disclaimer_ui import show_disclaimer_ui
from show_instructions import show_instructions_ui
from utils.tradelines_ui import show_tradeline_ui
from status_checker import update_status
from utils.cpn_utils import (
    generate_invalid_ssn,
    validate_ssn,
    style_label,
    create_grid_label,
    style_entry,
)

class AppBase:
    def __init__(self, root, mode="full"):
        self.root = root
        self.mode = mode
        self.root.title("CPN Creator")
        self.root.configure(bg="#1e1e1e")

        self.offline_popup_shown = False
        self.scanning = False
        self.is_online = True
        self.verifier = CPNVerifier(self.root)

        self.build_ui()
        show_home_content(self.inner_grid_frame, self)
        self.update_status()

    def update_status(self):
        update_status(self)

    def build_ui(self):
        header = tk.Label(self.root, text="🧠 CPN Creator", font=("Arial", 40, "bold"), pady=20, bg="#1e1e1e")
        style_label(header)
        header.pack()

        if self.mode == "lite":
            mode_label = tk.Label(self.root, text="🔒 Lite Mode Active", font=("Arial", 10, "bold"), bg="#1e1e1e", fg="orange")
            mode_label.pack()

        top_btn_frame = tk.Frame(self.root, bg="#1e1e1e")
        top_btn_frame.pack(pady=(0, 10))

        home_btn = ttk.Button(top_btn_frame, text="🏠 Home", width=20, command=self.go_home)
        home_btn.pack(side="left", padx=5)

        license_btn = ttk.Button(top_btn_frame, text="🔑 Enter License Key", width=25, command=self.prompt_license_key)
        license_btn.pack(side="left", padx=5)

        button_frame = tk.Frame(self.root, bg="#1e1e1e")
        button_frame.pack(pady=(2, 6))

        buttons = [
            "Generate a CPN to Use",
            "Verify The SSN",
            "Upload SSNs to Verify",
            "SSNs I've Clicked To Be Saved",
            "Verify If It's Already Used As A CPN",
            "Tradelines / Inquiry",
            "Instructions",
            "Contact Me",
            "Disclaimer"
        ]

        self.button_widgets = []
        for idx, text in enumerate(buttons):
            btn = ttk.Button(button_frame, text=text, width=30, command=lambda t=text: self.handle_button(t))
            btn.grid(row=idx // 3, column=idx % 3, padx=10, pady=10, ipadx=10, ipady=6)
            self.button_widgets.append(btn)

        if self.mode == "lite":
            for btn in self.button_widgets:
                if "Generate a CPN" in btn.cget("text") or "Saved" in btn.cget("text") or "Used As A CPN" in btn.cget("text"):
                    btn.config(state="disabled")

        self.scrollable = UniversalScrollableFrame(self.root)
        self.scrollable.pack(fill="both", expand=True, padx=20)
        self.scrollable.columnconfigure(0, weight=1)
        self.scrollable.rowconfigure(0, weight=1)

        self.inner_container = tk.Frame(self.scrollable.scrollable_frame, bg="#1e1e1e")
        self.inner_container.pack(fill="both", expand=True)
        self.inner_container.columnconfigure(0, weight=1)

        self.inner_grid_frame = tk.Frame(self.inner_container, bg="#1e1e1e")
        self.inner_grid_frame.pack(pady=10, anchor="center")

        footer_frame = tk.Frame(self.root, bg="#1e1e1e")
        footer_frame.pack(side="bottom", pady=10)

        self.status_label = tk.Label(
            footer_frame,
            text="● Checking... | For Educational Purpose Only",
            font=("Arial", 11),
            bg="#1e1e1e",
            fg="gray"
        )
        self.status_label.pack(anchor="center")

    def prompt_license_key(self):
        # Clear grid area
        for widget in self.inner_grid_frame.winfo_children():
            widget.destroy()

        tk.Label(
            self.inner_grid_frame,
            text="🔑 Enter Your License Key",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#1e1e1e"
        ).pack(pady=(10, 5))

        entry = tk.Entry(self.inner_grid_frame, font=("Courier", 14), width=30, justify="center")
        entry.pack(pady=(0, 10))
        entry.focus()

        result_label = tk.Label(self.inner_grid_frame, text="", font=("Arial", 11), bg="#1e1e1e")
        result_label.pack(pady=(5, 0))

        def submit_key():
            key = entry.get().strip()
            if not key:
                result_label.config(text="⚠️ No key entered.", fg="orange")
                return

            if key.startswith("FULL-"):
                mode = "full"
            elif key.startswith("LITE-"):
                mode = "lite"
            else:
                result_label.config(text="❌ Invalid license key.", fg="red")
                return

            try:
                with open("license.json", "w") as f:
                    json.dump({"license_key": key, "mode": mode}, f)
                result_label.config(text=f"✅ License accepted. Switching to {mode.upper()} Mode...", fg="lightgreen")
                self.root.after(1200, lambda: [self.root.destroy(), os.execl(sys.executable, sys.executable, *sys.argv)])
            except Exception as e:
                result_label.config(text=f"❌ Failed to save license: {e}", fg="red")

        submit_btn = tk.Button(
            self.inner_grid_frame,
            text="Activate",
            command=submit_key,
            font=("Arial", 12, "bold"),
            bg="white",
            fg="black",
            relief="flat",
            padx=10,
            pady=6
        )
        submit_btn.pack(pady=10)

    def go_home(self):
        for widget in self.inner_grid_frame.winfo_children():
            widget.destroy()
        show_home_content(self.inner_grid_frame, self)
        self.scrollable.canvas.yview_moveto(0)

    def handle_button(self, label):
        for widget in self.inner_grid_frame.winfo_children():
            widget.destroy()

        if label == "Generate a CPN to Use":
            self.generate_ssn_grid()
        elif label == "Verify The SSN":
            self.show_verify_ssn()
        elif label == "Upload SSNs to Verify":
            self.upload_ssn_file()
        elif label == "SSNs I've Clicked To Be Saved":
            self.show_ssn_history_in_grid()
        elif label == "Verify If It's Already Used As A CPN":
            self.generate_scan_grid()
        elif label == "Tradelines / Inquiry":
            show_tradeline_ui(self.inner_grid_frame)
        elif label == "Instructions":
            show_instructions_ui(self.inner_grid_frame)
        elif label == "Contact Me":
            show_contact_ui(self.inner_grid_frame)
        elif label == "Disclaimer":
            show_disclaimer_ui(self.inner_grid_frame)

        self.scrollable.canvas.yview_moveto(0)
        self.root.focus_set()

    def generate_ssn_grid(self):
        for i in range(4):
            for j in range(5):
                ssn = generate_invalid_ssn()
                create_grid_label(self.inner_grid_frame, ssn, i, j, fg="red", callback=self.copy_to_clipboard)

    def show_verify_ssn(self):
        self.ssn_entry = tk.Entry(self.inner_grid_frame, font=("Courier", 16), justify="center")
        self.ssn_entry.grid(row=0, column=0, columnspan=5, pady=10)
        style_entry(self.ssn_entry)
        self.ssn_entry.focus()

        def check_ssn():
            raw = self.ssn_entry.get().strip()
            digits = ''.join(filter(str.isdigit, raw))
            if len(digits) != 9:
                result = f"{raw} ❌ Invalid"
                color = "red"
            else:
                ssn = f"{digits[:3]}-{digits[3:5]}-{digits[5:]}"
                valid = validate_ssn(ssn)
                result = f"{ssn} ✅ Valid" if valid else f"{ssn} ❌ Invalid"
                color = "green" if valid else "red"

            result_label = tk.Label(self.inner_grid_frame, text=result, font=("Courier", 14))
            style_label(result_label, fg=color)
            result_label.grid(row=1, column=0, columnspan=5, pady=10)

        verify_btn = tk.Button(
            self.inner_grid_frame,
            text="Verify",
            command=check_ssn,
            bg="white", fg="black",
            activebackground="#ccc",
            activeforeground="black",
            disabledforeground="gray",
            highlightbackground="white",
            highlightcolor="white",
            relief="flat"
        )
        verify_btn.grid(row=2, column=0, columnspan=5, pady=10)
        bind_return_key(self.ssn_entry, check_ssn)

    def upload_ssn_file(self):
        try:
            path = filedialog.askopenfilename(filetypes=[("Supported", "*.txt *.csv *.docx *.png *.jpg")])
            if not path: return

            if path.endswith(".docx"):
                doc = Document(path)
                content = "\n".join(p.text for p in doc.paragraphs)
            elif path.lower().endswith((".png", ".jpg", ".jpeg")):
                content = pytesseract.image_to_string(Image.open(path))
            else:
                with open(path, "r") as f:
                    content = f.read()

            ssns = re.findall(r"\d{3}-\d{2}-\d{4}", content)
            if not ssns:
                messagebox.showinfo("No SSNs", "No valid SSNs found in the file.")
                return

            for i, ssn in enumerate(ssns):
                row, col = divmod(i, 5)
                color = "green" if validate_ssn(ssn) else "red"
                create_grid_label(self.inner_grid_frame, ssn, row, col, fg=color, callback=self.copy_to_clipboard)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to read file: {e}")

    def generate_scan_grid(self):
        for widget in self.inner_grid_frame.winfo_children():
            widget.destroy()

        self.scan_labels = []
        ssns = [generate_invalid_ssn() for _ in range(4)]

        for j, ssn in enumerate(ssns):
            label = create_grid_label(self.inner_grid_frame, ssn, 0, j, fg="red")
            label.bind("<Button-1>", lambda e, s=ssn, l=label, idx=j: self.scan_chain.start_from(idx))
            self.scan_labels.append(label)

        self.scan_chain = AutoScanChain(self, self.scan_labels)
        self.verifier.is_scanning = False
        self.scanning = False

    def copy_to_clipboard(self, ssn, event=None):
        self.root.clipboard_clear()
        self.root.clipboard_append(ssn)
        self.root.update()
        x = event.x_root - self.root.winfo_rootx() if event else self.root.winfo_width() // 2
        y = event.y_root - self.root.winfo_rooty() if event else 20
        label = tk.Label(self.root, text="✅ Copied", bg="#1e1e1e", fg="lightgreen", font=("Arial", 10))
        label.place(x=x, y=y)
        label.after(1500, label.destroy)

    def show_ssn_history_in_grid(self):
        history_file = "cpn_verification_history.json"
        for widget in self.inner_grid_frame.winfo_children():
            widget.destroy()
        try:
            if os.path.exists(history_file):
                with open(history_file, "r") as f:
                    history = json.load(f)
            else:
                history = []
        except json.JSONDecodeError:
            history = []

        if not history:
            tk.Label(self.inner_grid_frame, text="No saved SSNs.", bg="#1e1e1e", fg="yellow").grid(row=0, column=0, pady=20)
            return

        for index, rec in enumerate(history):
            text = f"{rec['timestamp']} - {rec['ssn']} - {rec['result']}"
            row, col = divmod(index, 4)
            label = tk.Label(self.inner_grid_frame, text=text, bg="#222", fg="white", font=("Arial", 10), cursor="hand2")
            label.grid(row=row, column=col, padx=10, pady=4, sticky="w")
            label.bind("<Button-1>", lambda e, s=rec['ssn']: self.copy_to_clipboard(s, e))

    def clear_scanning_ui(self):
        if hasattr(self, "scanning_stage_log") and self.scanning_stage_log:
            self.scanning_stage_log.destroy()
            self.scanning_stage_log = None
        self.scanning = False
        self.verifier.is_scanning = False
