from apps.app_base import AppBase

class FullApp(AppBase):
    def __init__(self, root):
        super().__init__(root, mode="full")
