# apps/lite_app.py
from apps.app_base import AppBase

class LiteApp(AppBase):
    def __init__(self, root):
        super().__init__(root, mode="lite")
